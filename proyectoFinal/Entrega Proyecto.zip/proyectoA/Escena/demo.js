var scene, camera, renderer, mesh, cub;
var meshFloor, ambientLight, light;

var keyboard = {};
var player = { height:1.8, speed:0.2, turnSpeed:Math.PI*0.02 };
var USE_WIREFRAME = false;

function init(){
	scene = new THREE.Scene();
	aspect = window.innerWidth / window.innerHeight;
            camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
	renderer = new THREE.WebGLRenderer();
            renderer.setSize(window.innerWidth, window.innerHeight);
    
//ELEMENTOS COMUNES
             var size = 70;
            var arrowSize = 1;
            var divisions = size;
            var origin = new THREE.Vector3(0, 0, 0);
            var x = new THREE.Vector3(1, 0, 0);
            var y = new THREE.Vector3(0, 1, 0);
            var z = new THREE.Vector3(0, 0, 1);
            var color = new THREE.Color(0x333333);
            var colorR = new THREE.Color(0xAA3333);
            var colorG = new THREE.Color(0x33AA33);
            var colorB = new THREE.Color(0x333366);

           //CREAR LAS GRILLAS PARA EL ESCENARIO
            var axesHelper = new THREE.AxesHelper(size);
            scene.add(axesHelper);

            var gridHelperXZ = new THREE.GridHelper(size, divisions, color, color);
            scene.add(gridHelperXZ);

            //ROTARLAS PARA QUE QUEDEN EN EL ESPACIO ADECUADO
            gridHelperXZ.rotateOnWorldAxis(y, THREE.Math.degToRad(90));
    
    
    
    //GEO
    
	meshFloor = new THREE.Mesh(
		new THREE.PlaneGeometry(70,70, 70,70),
		// MeshBasicMaterial does not react to lighting, so we replace with MeshPhongMaterial
		new THREE.MeshPhongMaterial({color:0x35682d, wireframe:USE_WIREFRAME})
		// See threejs.org/examples/ for other material types
		
		
	);
	meshFloor.rotation.x -= Math.PI / 2;
	// Floor can have shadows cast onto it
	meshFloor.receiveShadow = true;
	scene.add(meshFloor);
  
// CARRETERA
    
            var geoVia = new THREE.BoxGeometry( 70, 0.2, 70 , 70);
            var geoVia1 = new THREE.BoxGeometry( 35, 1, 15 , 10);
            var geoVia2 = new THREE.BoxGeometry( 55, 1, 15 , 10);
            
            var geoVia3 = new THREE.BoxGeometry( 60, 1, 5 , 10);
            var matVia= new THREE.MeshPhongMaterial( {color: 0x787878, side: THREE.DoubleSide} );
           
            var Via1 = new THREE.Mesh( geoVia, matVia );
            var Via2 = new THREE.Mesh( geoVia1, matVia );
            var Via3 = new THREE.Mesh( geoVia1, matVia );
            var Via4 = new THREE.Mesh( geoVia1, matVia );
            var Via5 = new THREE.Mesh( geoVia1, matVia );
            var Via6 = new THREE.Mesh( geoVia2, matVia );
            
            var Via7= new THREE.Mesh( geoVia3, matVia );
            var Via8= new THREE.Mesh( geoVia3, matVia );
            
            
            Via2.position.x=25;
            Via2.position.z=20;
           
            
            Via3.position.x=-20;
            Via3.position.z=30;
            
            Via4.position.x=-20;
            Via4.position.z=5;
            
            Via5.position.x=25;
            Via5.position.z=-5;
            
            Via6.position.x=0;
            Via6.position.z=-30;
            
            Via7.position.x=20;
            Via7.position.z=-12.5;
            
             
            Via8.position.x=-50;
            Via8.position.z=-12.5;

            var Via1CSG = THREE.CSG.fromMesh(Via1);
            var Via2CSG = THREE.CSG.fromMesh(Via2);
            var Via3CSG = THREE.CSG.fromMesh(Via3);
            var Via4CSG = THREE.CSG.fromMesh(Via4);
            var Via5CSG = THREE.CSG.fromMesh(Via5);
            var Via6CSG = THREE.CSG.fromMesh(Via6);
            var Via7CSG = THREE.CSG.fromMesh(Via7);
            var Via8CSG = THREE.CSG.fromMesh(Via8);
              
    
    //hacer Operaciones CSG

            var result1 = Via1CSG.subtract(Via2CSG).subtract(Via3CSG).subtract(Via4CSG).subtract(Via5CSG).subtract(Via6CSG).subtract(Via7CSG).subtract(Via8CSG);

            //compilar

            var Calle = THREE.CSG.toMesh(result1);
            Calle.material=matVia;
    
             scene.add(Calle);
    
    
//CASAS

	  var geometry = new THREE.BoxGeometry( 10, 10, 5);
            var geometrya = new THREE.BoxGeometry( 10, 10, 5 );
            var geometry2 = new THREE.BoxGeometry( 4, 4, 4 );
            var geometry3 = new THREE.BoxGeometry( 15, 10, 6 );
            var geometry4 = new THREE.BoxGeometry( 4, 7, 4 );
            var geometry5 = new THREE.BoxGeometry( 30, 10, 6 );
            var geometry7 = new THREE.BoxGeometry( 6, 6, 10 );
            
            var material = new THREE.MeshBasicMaterial( {color: 0x66CDAA} );
            var material2 = new THREE.MeshBasicMaterial( {color: 0x0000FF} );
            var material3 = new THREE.MeshBasicMaterial( {color: 0xFF0000} );
            var material4 = new THREE.MeshBasicMaterial( {color: 0xF0E68C} );
            
            var Casa1 = new THREE.Mesh( geometry, material );
            var Casa1a = new THREE.Mesh( geometrya, material );
            var Casa2 = new THREE.Mesh( geometry, material2 );
            var Casa2a = new THREE.Mesh( geometry, material2 );
            var Casa3 = new THREE.Mesh( geometry3, material3 );
            var Casa4 = new THREE.Mesh( geometry5, material4 );
           
   
           
            Casa1.rotation.y=1.57;
            Casa1a.rotation.y=3.15;
			Casa1a.position.x=7;
            Casa1a.position.z=2.5;
		
            Casa2.rotation.y=1.57;
			Casa2.position.x=6.5;
            Casa2a.rotation.y=3.15;
			Casa2a.position.x=4;
	        Casa2a.position.z=-5;
    
       
          
            var Casa1CSG = THREE.CSG.fromMesh(Casa1);
            var Casa1aCSG = THREE.CSG.fromMesh(Casa1a);
            var Casa2CSG = THREE.CSG.fromMesh(Casa2);
            var Casa2aCSG = THREE.CSG.fromMesh(Casa2a);
            var Casa3CSG = THREE.CSG.fromMesh(Casa3);
            var Casa4CSG = THREE.CSG.fromMesh(Casa4);

            
             //hacer Operaciones CSG

            var result2 = Casa1CSG.union(Casa1aCSG);
            var result3 = Casa2CSG.union(Casa2aCSG);
            var result4 =  Casa3CSG;
            var result5 =  Casa4CSG;
            
            
            //compilar

            var CasaA = THREE.CSG.toMesh(result2);
            var CasaB = THREE.CSG.toMesh(result3);
            var CasaC = THREE.CSG.toMesh(result4);
            var CasaD = THREE.CSG.toMesh(result5);
            
            CasaA.material=material;
            CasaB.material=material2;
            CasaC.material=material3;
            CasaD.material=material4;
            
            CasaA.position.x=-20;
            CasaA.position.y=4.5;
            CasaA.position.z=4.5;
            
            CasaB.position.x=15;
            CasaB.position.y=4.5;
            CasaB.position.z=-4.5;
            
            CasaC.rotation.y=3.15;
            CasaC.position.x=20;
            CasaC.position.y=4.5;
			CasaC.position.z=20;

            CasaD.position.y=4.5;
            CasaD.position.z=-30; 

            scene.add(CasaA);
            scene.add(CasaB);
            scene.add(CasaC);
            scene.add(CasaD);
            
	/// LIGHTS
	ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
	scene.add(ambientLight);
    
    var pointLight = new THREE.PointLight(0xffffff, 1, 40);
            pointLight.position.set(-10, -12, 10);
            scene.add(pointLight);

            var pointLight = new THREE.PointLight(0xffffff, .5, 40);
            pointLight.position.set(10, -12, -10);
            scene.add(pointLight);
	
	light = new THREE.PointLight(0xffffff, 0.8, 18);
	light.position.set(-3,10,-3);
	light.castShadow = true;
	// Will not light anything closer than 0.1 units or further than 25 units
	light.shadow.camera.near = 0.1;
	light.shadow.camera.far = 25;
	scene.add(light); 
	
	
	camera.position.set(0, player.height, -5);
	camera.lookAt(new THREE.Vector3(0,player.height,0));
	
	
	
	// Enable Shadows in the Renderer
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = THREE.BasicShadowMap;
	
	document.body.appendChild(renderer.domElement);
	
	animate();
}

  


function animate(){
	requestAnimationFrame(animate);
	
	
	if(keyboard[87]){ // W key
		camera.position.x -= Math.sin(camera.rotation.y) * player.speed;
		camera.position.z -= -Math.cos(camera.rotation.y) * player.speed;
	}
	if(keyboard[83]){ // S key
		camera.position.x += Math.sin(camera.rotation.y) * player.speed;
		camera.position.z += -Math.cos(camera.rotation.y) * player.speed;
	}
	if(keyboard[65]){ // A key
		camera.position.x += Math.sin(camera.rotation.y + Math.PI/2) * player.speed;
		camera.position.z += -Math.cos(camera.rotation.y + Math.PI/2) * player.speed;
	}
	if(keyboard[68]){ // D key
		camera.position.x += Math.sin(camera.rotation.y - Math.PI/2) * player.speed;
		camera.position.z += -Math.cos(camera.rotation.y - Math.PI/2) * player.speed;
	}
	
	if(keyboard[37]){ // left arrow key
		camera.rotation.y -= player.turnSpeed;
	}
	if(keyboard[39]){ // right arrow key
		camera.rotation.y += player.turnSpeed;
	}
	
	renderer.render(scene, camera);
}

function keyDown(event){
	keyboard[event.keyCode] = true;
}

function keyUp(event){
	keyboard[event.keyCode] = false;
}

window.addEventListener('keydown', keyDown);
window.addEventListener('keyup', keyUp);

window.onload = init;
